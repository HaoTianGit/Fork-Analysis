import React, { useState, useEffect } from 'react';
//import Table from '@material-ui/core/Table';
//import TableBody from '@material-ui/core/TableBody';
//import TableCell from '@material-ui/core/TableCell';
//import TableHead from '@material-ui/core/TableHead';
//import TableRow from '@material-ui/core/TableRow';

interface IState {
    result:any[];
   // url:any[]

}
interface ITableDisplayProps{
    SearchQuery: (String | null);
}
//techgaun/active-forks
//https://api.github.com/repos/techgaun/active-forks/forks?sort=stargazers&per_page=100
function TableDisplay(props: ITableDisplayProps){
    const [ItemArray, setItemArray] = useState<IState[]>([{result:[]}])
    useEffect(() => {
        fetch('https://api.github.com/repos/'+ props.SearchQuery+'/forks')//change later
            .then(response =>response.json())
            //.then(data => console.log(data[0].owner.login))
            //.then(response => response.items)
            .then(response => setItemArray(response))
            //.then(() => console.log())
            .catch(() => console.log("it didn't work")
        );

    }, [props.SearchQuery]);
    ItemArray.forEach((item:IState) => {
        console.log(item);
    })
    return(
        <div>
                <table className="table">
                    <tr>
                        <th>username</th>
                        <th>url</th>
                    </tr>
                    <tbody className="captionTable">
        
                    </tbody>
                </table>            
            
        </div>
    )
}


export default TableDisplay