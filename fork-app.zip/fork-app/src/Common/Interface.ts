export interface IUserInput {
    SearchQuery: (string |null );

}